# Rudenko Nail School — «Укріплення без довжини»

Лендинг онлайн-курсу. Статичний проєкт: HTML + CSS + JS, без збірки й залежностей.

## Структура

```
index.html      — розмітка сторінки
style.css       — стилі
script.js       — скрол-анімації, акордеон програми, лайтбокс галереї
hero.jpg, gallery-1.jpg … gallery-4.jpg — фото (лежать у корені поруч з index.html)
```

Відео підключене через YouTube-ембед (без локального файлу) — це найнадійніший спосіб відтворення на будь-яких пристроях.

## Як опублікувати на GitHub Pages

1. Створи новий репозиторій на GitHub і залий у нього вміст цієї папки (можна перетягнути файли у веб-інтерфейсі GitHub або через git):
   ```
   git init
   git add .
   git commit -m "Landing page"
   git branch -M main
   git remote add origin https://github.com/<твій-акаунт>/<назва-репозиторію>.git
   git push -u origin main
   ```
2. У репозиторії відкрий **Settings → Pages**.
3. У розділі **Build and deployment** вибери джерело **Deploy from a branch**, гілку **main** і папку **/ (root)**.
4. Збережи — за хвилину-дві сайт буде доступний за адресою
   `https://<твій-акаунт>.github.io/<назва-репозиторію>/`

## Що варто перевірити перед публікацією

- Посилання «Придбати курс» ведуть у Telegram: `https://t.me/nail_anna_rudenko`
- Instagram у футері: `https://www.instagram.com/nail_anna_rudenko`
- Ціна: 399 грн замість 1000 грн (блок у hero і перед фінальною кнопкою)
